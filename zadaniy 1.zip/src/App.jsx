import { Routes, Route, Navigate } from 'react-router-dom';
import BoardsList from './pages/BoardsList';
import BoardPage from './pages/BoardPage';
import NotFound from './pages/NotFound';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/boards" replace />} />
      <Route path="/boards" element={<BoardsList />} />
      <Route path="/boards/:id" element={<BoardPage />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;