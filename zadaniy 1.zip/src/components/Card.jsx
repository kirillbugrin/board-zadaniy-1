import { useState } from 'react';
import { useBoard } from '../context/BoardContext';

export default function Card({ cardId, columnId }) {
  const { state, dispatch } = useBoard();
  const [isEditing, setIsEditing] = useState(false);
  const [editingValue, setEditingValue] = useState('');
  const card = state.cards.byId[cardId];

  if (!card) return null;

  const startEdit = () => {
    setIsEditing(true);
    setEditingValue(card.title);
  };

  const saveEdit = () => {
    const trimmed = editingValue.trim();
    if (trimmed) {
      dispatch({ type: 'RENAME_CARD', payload: { id: cardId, title: trimmed } });
    }
    setIsEditing(false);
    setEditingValue('');
  };

  const cancelEdit = () => {
    setIsEditing(false);
    setEditingValue('');
  };

  const handleDelete = () => {
    dispatch({ type: 'DELETE_CARD', payload: { id: cardId, columnId } });
  };

  return (
    <div
      style={{
        background: '#fff',
        padding: 10,
        marginBottom: 6,
        borderRadius: 4,
        boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
      }}
    >
      {isEditing ? (
        <input
          autoFocus
          value={editingValue}
          onChange={(e) => setEditingValue(e.target.value)}
          onBlur={saveEdit}
          onKeyDown={(e) => {
            if (e.key === 'Enter') saveEdit();
            if (e.key === 'Escape') cancelEdit();
          }}
          style={{ width: '100%', padding: 4, marginBottom: 6, boxSizing: 'border-box' }}
        />
      ) : (
        <div style={{ marginBottom: 6 }}>{card.title}</div>
      )}
      <div style={{ display: 'flex', gap: 4 }}>
        <button type="button" onClick={startEdit}>✏️</button>
        <button type="button" onClick={handleDelete}>🗑️</button>
      </div>
    </div>
  );
}