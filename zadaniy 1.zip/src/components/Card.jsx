import { useBoard } from '../context/BoardContext';

export default function Card({ cardId, columnId }) {
  const { state, dispatch } = useBoard();
  const card = state.cards.byId[cardId];

  if (!card) return null;

  return (
    <div
      style={{
        background: '#fff',
        padding: 10,
        marginBottom: 6,
        borderRadius: 4,
        boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
      }}
    >
      <div style={{ marginBottom: 6 }}>{card.title}</div>
      <div style={{ display: 'flex', gap: 4 }}>
        <button
          onClick={() => {
            const newTitle = prompt('Редактировать карточку:', card.title);
            if (newTitle && newTitle.trim()) {
              dispatch({ type: 'RENAME_CARD', payload: { id: cardId, title: newTitle.trim() } });
            }
          }}
        >
          ✏️
        </button>
        <button
          onClick={() => {
            dispatch({ type: 'DELETE_CARD', payload: { id: cardId, columnId } });
          }}
        >
          🗑️
        </button>
      </div>
    </div>
  );
}