import { useState } from 'react';
import { useBoard } from '../context/BoardContext';
import Card from './Card';

export default function Column({ columnId, boardId }) {
  const { state, dispatch } = useBoard();
  const [newCardTitle, setNewCardTitle] = useState('');
  const column = state.columns.byId[columnId];

  if (!column) return null;

  const handleAddCard = (e) => {
    e.preventDefault();
    if (!newCardTitle.trim()) return;
    dispatch({ type: 'ADD_CARD', payload: { columnId, title: newCardTitle.trim() } });
    setNewCardTitle('');
  };

  return (
    <div
      style={{
        border: '1px solid #ddd',
        padding: 10,
        minWidth: 260,
        background: '#f9f9f9',
        borderRadius: 8,
        flexShrink: 0,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ margin: '0 0 8px 0' }}>{column.title}</h3>
        <div>
          <button
            onClick={() => {
              const newTitle = prompt('Переименовать колонку:', column.title);
              if (newTitle && newTitle.trim()) {
                dispatch({ type: 'RENAME_COLUMN', payload: { id: columnId, title: newTitle.trim() } });
              }
            }}
            style={{ marginRight: 4 }}
          >
            ✏️
          </button>
          <button
            onClick={() => {
              if (confirm(`Удалить колонку "${column.title}"?`)) {
                dispatch({ type: 'DELETE_COLUMN', payload: { id: columnId, boardId } });
              }
            }}
          >
            🗑️
          </button>
        </div>
      </div>

      <form onSubmit={handleAddCard} style={{ margin: '8px 0' }}>
        <input
          value={newCardTitle}
          onChange={(e) => setNewCardTitle(e.target.value)}
          placeholder="Новая карточка"
          style={{ width: '100%', marginBottom: 5, padding: 6, boxSizing: 'border-box' }}
        />
        <button type="submit" style={{ width: '100%', padding: 6 }}>+ Карточка</button>
      </form>

      <div>
        {column.cardIds.map((cardId) => (
          <Card key={cardId} cardId={cardId} columnId={columnId} />
        ))}
      </div>
    </div>
  );
}