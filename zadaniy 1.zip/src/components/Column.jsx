import { useState } from 'react';
import { useBoard } from '../context/BoardContext';
import Card from './Card';

export default function Column({ columnId, boardId }) {
  const { state, dispatch } = useBoard();
  const [newCardTitle, setNewCardTitle] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editingValue, setEditingValue] = useState('');
  const column = state.columns.byId[columnId];

  if (!column) return null;

  const handleAddCard = (e) => {
    e.preventDefault();
    const trimmed = newCardTitle.trim();
    if (!trimmed) return;
    dispatch({ type: 'ADD_CARD', payload: { columnId, title: trimmed } });
    setNewCardTitle('');
  };

  const startEdit = () => {
    setIsEditing(true);
    setEditingValue(column.title);
  };

  const saveEdit = () => {
    const trimmed = editingValue.trim();
    if (trimmed) {
      dispatch({ type: 'RENAME_COLUMN', payload: { id: columnId, title: trimmed } });
    }
    setIsEditing(false);
    setEditingValue('');
  };

  const cancelEdit = () => {
    setIsEditing(false);
    setEditingValue('');
  };

  const handleDelete = () => {
    if (window.confirm(`Удалить колонку "${column.title}"?`)) {
      dispatch({ type: 'DELETE_COLUMN', payload: { id: columnId, boardId } });
    }
  };

  return (
    <div
      style={{
        border: '1px solid #ddd',
        padding: 10,
        minWidth: 260,
        background: '#f9f9f9',
        borderRadius: 8,
        flexShrink: 0,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        {isEditing ? (
          <input
            autoFocus
            value={editingValue}
            onChange={(e) => setEditingValue(e.target.value)}
            onBlur={saveEdit}
            onKeyDown={(e) => {
              if (e.key === 'Enter') saveEdit();
              if (e.key === 'Escape') cancelEdit();
            }}
            style={{ flex: 1, fontSize: 16, padding: 4, marginRight: 4 }}
          />
        ) : (
          <h3 style={{ margin: '0 0 8px 0' }}>{column.title}</h3>
        )}
        <div style={{ display: 'flex', gap: 4 }}>
          <button type="button" onClick={startEdit}>✏️</button>
          <button type="button" onClick={handleDelete}>🗑️</button>
        </div>
      </div>

      <form onSubmit={handleAddCard} style={{ margin: '8px 0' }}>
        <input
          value={newCardTitle}
          onChange={(e) => setNewCardTitle(e.target.value)}
          placeholder="Новая карточка"
          style={{ width: '100%', marginBottom: 5, padding: 6, boxSizing: 'border-box' }}
        />
        <button type="submit" style={{ width: '100%', padding: 6 }}>+ Карточка</button>
      </form>

      <div>
        {column.cardIds.map((cardId) => (
          <Card key={cardId} cardId={cardId} columnId={columnId} />
        ))}
      </div>
    </div>
  );
}