import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const BoardContext = createContext();

const initialState = {
  boards: { byId: {}, allIds: [] },
  columns: { byId: {}, allIds: [] },
  cards: { byId: {}, allIds: [] },
};

const generateId = () => Math.random().toString(36).substring(2, 9);

function reducer(state, action) {
  switch (action.type) {
    // ---------- BOARDS ----------
    case 'ADD_BOARD': {
      const id = generateId();
      const newBoard = { id, title: action.payload.title, columnIds: [] };
      return {
        ...state,
        boards: {
          byId: { ...state.boards.byId, [id]: newBoard },
          allIds: [...state.boards.allIds, id],
        },
      };
    }

    case 'RENAME_BOARD': {
      const { id, title } = action.payload;
      return {
        ...state,
        boards: {
          ...state.boards,
          byId: { ...state.boards.byId, [id]: { ...state.boards.byId[id], title } },
        },
      };
    }

    case 'DELETE_BOARD': {
      const { id } = action.payload;
      const board = state.boards.byId[id];
      if (!board) return state;

      const newColumnsById = { ...state.columns.byId };
      const newCardsById = { ...state.cards.byId };
      const removedColumnIds = [];
      const removedCardIds = [];

      board.columnIds.forEach((colId) => {
        const column = state.columns.byId[colId];
        if (!column) return;
        column.cardIds.forEach((cardId) => {
          delete newCardsById[cardId];
          removedCardIds.push(cardId);
        });
        delete newColumnsById[colId];
        removedColumnIds.push(colId);
      });

      return {
        boards: {
          byId: Object.fromEntries(
            Object.entries(state.boards.byId).filter(([key]) => key !== id)
          ),
          allIds: state.boards.allIds.filter((bId) => bId !== id),
        },
        columns: {
          byId: newColumnsById,
          allIds: state.columns.allIds.filter((cId) => !removedColumnIds.includes(cId)),
        },
        cards: {
          byId: newCardsById,
          allIds: state.cards.allIds.filter((cId) => !removedCardIds.includes(cId)),
        },
      };
    }

    // ---------- COLUMNS ----------
    case 'ADD_COLUMN': {
      const { boardId, title } = action.payload;
      const id = generateId();
      const newColumn = { id, title, cardIds: [] };
      const board = state.boards.byId[boardId];

      return {
        ...state,
        boards: {
          ...state.boards,
          byId: {
            ...state.boards.byId,
            [boardId]: { ...board, columnIds: [...board.columnIds, id] },
          },
        },
        columns: {
          byId: { ...state.columns.byId, [id]: newColumn },
          allIds: [...state.columns.allIds, id],
        },
      };
    }

    case 'RENAME_COLUMN': {
      const { id, title } = action.payload;
      return {
        ...state,
        columns: {
          ...state.columns,
          byId: { ...state.columns.byId, [id]: { ...state.columns.byId[id], title } },
        },
      };
    }

    case 'DELETE_COLUMN': {
      const { id, boardId } = action.payload;
      const column = state.columns.byId[id];
      const board = state.boards.byId[boardId];
      if (!column || !board) return state;

      const newCardsById = { ...state.cards.byId };
      column.cardIds.forEach((cardId) => delete newCardsById[cardId]);

      return {
        ...state,
        boards: {
          ...state.boards,
          byId: {
            ...state.boards.byId,
            [boardId]: {
              ...board,
              columnIds: board.columnIds.filter((cId) => cId !== id),
            },
          },
        },
        columns: {
          byId: Object.fromEntries(
            Object.entries(state.columns.byId).filter(([key]) => key !== id)
          ),
          allIds: state.columns.allIds.filter((cId) => cId !== id),
        },
        cards: {
          byId: newCardsById,
          allIds: state.cards.allIds.filter((cId) => !column.cardIds.includes(cId)),
        },
      };
    }

    // ---------- CARDS ----------
    case 'ADD_CARD': {
      const { columnId, title } = action.payload;
      const id = generateId();
      const newCard = { id, title };
      const column = state.columns.byId[columnId];

      return {
        ...state,
        columns: {
          ...state.columns,
          byId: {
            ...state.columns.byId,
            [columnId]: { ...column, cardIds: [...column.cardIds, id] },
          },
        },
        cards: {
          byId: { ...state.cards.byId, [id]: newCard },
          allIds: [...state.cards.allIds, id],
        },
      };
    }

    case 'RENAME_CARD': {
      const { id, title } = action.payload;
      return {
        ...state,
        cards: {
          ...state.cards,
          byId: { ...state.cards.byId, [id]: { ...state.cards.byId[id], title } },
        },
      };
    }

    case 'DELETE_CARD': {
      const { id, columnId } = action.payload;
      const column = state.columns.byId[columnId];
      if (!column) return state;

      return {
        ...state,
        columns: {
          ...state.columns,
          byId: {
            ...state.columns.byId,
            [columnId]: {
              ...column,
              cardIds: column.cardIds.filter((cId) => cId !== id),
            },
          },
        },
        cards: {
          byId: Object.fromEntries(
            Object.entries(state.cards.byId).filter(([key]) => key !== id)
          ),
          allIds: state.cards.allIds.filter((cId) => cId !== id),
        },
      };
    }

    default:
      return state;
  }
}

export const BoardProvider = ({ children }) => {
  const [savedState, setSavedState] = useLocalStorage('kanban-state', initialState);
  const [state, dispatch] = useReducer(reducer, savedState);

  useEffect(() => {
    setSavedState(state);
  }, [state, setSavedState]);

  return (
    <BoardContext.Provider value={{ state, dispatch }}>
      {children}
    </BoardContext.Provider>
  );
};

export const useBoard = () => useContext(BoardContext);