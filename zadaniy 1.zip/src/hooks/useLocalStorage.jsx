import { useState, useEffect } from 'react';

export const useLocalStorage = (key, initialValue, delay = 500) => {
  const [value, setValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error('Ошибка чтения localStorage:', error);
      return initialValue;
    }
  });

  useEffect(() => {
    const handler = setTimeout(() => {
      try {
        window.localStorage.setItem(key, JSON.stringify(value));
      } catch (error) {
        console.error('Ошибка записи в localStorage:', error);
      }
    }, delay);

    return () => clearTimeout(handler);
  }, [key, value, delay]);

  return [value, setValue];
};