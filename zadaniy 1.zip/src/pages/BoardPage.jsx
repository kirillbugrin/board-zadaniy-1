import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useBoard } from '../context/BoardContext';
import Column from '../components/Column';

export default function BoardPage() {
  const { id } = useParams();
  const { state, dispatch } = useBoard();
  const [newColTitle, setNewColTitle] = useState('');

  const board = state.boards.byId[id];

  if (!board) {
    return (
      <div style={{ padding: 40, textAlign: 'center' }}>
        <h2>Доска не найдена 🤔</h2>
        <Link to="/boards">← Назад к списку досок</Link>
      </div>
    );
  }

  const handleAddColumn = (e) => {
    e.preventDefault();
    const trimmed = newColTitle.trim();
    if (!trimmed) return;
    dispatch({ type: 'ADD_COLUMN', payload: { boardId: id, title: trimmed } });
    setNewColTitle('');
  };

  return (
    <div style={{ padding: 20 }}>
      <Link to="/boards">← Назад к доскам</Link>
      <h1>{board.title}</h1>

      <form onSubmit={handleAddColumn} style={{ marginBottom: 20, display: 'flex', gap: 8 }}>
        <input
          value={newColTitle}
          onChange={(e) => setNewColTitle(e.target.value)}
          placeholder="Название колонки"
          style={{ padding: 8, flex: 1, maxWidth: 300 }}
        />
        <button type="submit" style={{ padding: '8px 16px' }}>+ Колонка</button>
      </form>

      <div style={{ display: 'flex', gap: 16, overflowX: 'auto', alignItems: 'flex-start' }}>
        {board.columnIds.map((colId) => (
          <Column key={colId} columnId={colId} boardId={id} />
        ))}
      </div>
    </div>
  );
}