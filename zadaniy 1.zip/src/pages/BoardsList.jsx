import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useBoard } from '../context/BoardContext';

export default function BoardsList() {
  const { state, dispatch } = useBoard();
  const [newBoardTitle, setNewBoardTitle] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editingValue, setEditingValue] = useState('');

  const handleAddBoard = (e) => {
    e.preventDefault();
    const trimmed = newBoardTitle.trim();
    if (!trimmed) return;
    dispatch({ type: 'ADD_BOARD', payload: { title: trimmed } });
    setNewBoardTitle('');
  };

  const startEdit = (id, currentTitle) => {
    setEditingId(id);
    setEditingValue(currentTitle);
  };

  const saveEdit = () => {
    const trimmed = editingValue.trim();
    if (trimmed && editingId) {
      dispatch({ type: 'RENAME_BOARD', payload: { id: editingId, title: trimmed } });
    }
    setEditingId(null);
    setEditingValue('');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditingValue('');
  };

  const handleDelete = (id, title) => {
    if (window.confirm(`Удалить доску "${title}"?`)) {
      dispatch({ type: 'DELETE_BOARD', payload: { id } });
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 800, margin: '0 auto' }}>
      <h1>📋 Мои доски</h1>

      <form onSubmit={handleAddBoard} style={{ marginBottom: 20, display: 'flex', gap: 8 }}>
        <input
          value={newBoardTitle}
          onChange={(e) => setNewBoardTitle(e.target.value)}
          placeholder="Название новой доски"
          style={{ padding: 8, flex: 1 }}
        />
        <button type="submit" style={{ padding: '8px 16px' }}>Создать</button>
      </form>

      {state.boards.allIds.length === 0 && <p>Пока нет ни одной доски. Создайте первую!</p>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {state.boards.allIds.map((id) => {
          const board = state.boards.byId[id];
          if (!board) return null;
          const isEditing = editingId === id;

          return (
            <li
              key={id}
              style={{
                marginBottom: 10,
                padding: 10,
                background: '#fff',
                borderRadius: 6,
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              }}
            >
              {isEditing ? (
                <input
                  autoFocus
                  value={editingValue}
                  onChange={(e) => setEditingValue(e.target.value)}
                  onBlur={saveEdit}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') saveEdit();
                    if (e.key === 'Escape') cancelEdit();
                  }}
                  style={{ flex: 1, fontSize: 18, padding: 4 }}
                />
              ) : (
                <Link
                  to={`/boards/${id}`}
                  style={{ fontSize: 18, flex: 1, textDecoration: 'none', color: '#333' }}
                >
                  {board.title}
                </Link>
              )}
              <button type="button" onClick={() => startEdit(id, board.title)}>✏️</button>
              <button type="button" onClick={() => handleDelete(id, board.title)}>🗑️</button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}