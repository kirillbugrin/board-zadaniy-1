import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useBoard } from '../context/BoardContext';

export default function BoardsList() {         // ✅ export default
  const { state, dispatch } = useBoard();
  const [newBoardTitle, setNewBoardTitle] = useState('');

  const handleAddBoard = (e) => {
    e.preventDefault();
    if (!newBoardTitle.trim()) return;
    dispatch({ type: 'ADD_BOARD', payload: { title: newBoardTitle.trim() } });
    setNewBoardTitle('');
  };

  return (
    <div style={{ padding: 20, maxWidth: 800, margin: '0 auto' }}>
      <h1>📋 Мои доски</h1>

      <form onSubmit={handleAddBoard} style={{ marginBottom: 20, display: 'flex', gap: 8 }}>
        <input
          value={newBoardTitle}
          onChange={(e) => setNewBoardTitle(e.target.value)}
          placeholder="Название новой доски"
          style={{ padding: 8, flex: 1 }}
        />
        <button type="submit" style={{ padding: '8px 16px' }}>Создать</button>
      </form>

      {state.boards.allIds.length === 0 && (
        <p>Пока нет ни одной доски. Создайте первую!</p>
      )}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {state.boards.allIds.map((id) => {
          const board = state.boards.byId[id];
          return (
            <li
              key={id}
              style={{
                marginBottom: 10,
                padding: 10,
                background: '#fff',
                borderRadius: 6,
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              }}
            >
              <Link
                to={`/boards/${id}`}
                style={{ fontSize: 18, flex: 1, textDecoration: 'none', color: '#333' }}
              >
                {board.title}
              </Link>
              <button
                onClick={() => {
                  const newTitle = prompt('Новое название:', board.title);
                  if (newTitle && newTitle.trim()) {
                    dispatch({ type: 'RENAME_BOARD', payload: { id, title: newTitle.trim() } });
                  }
                }}
              >
                ✏️
              </button>
              <button
                onClick={() => {
                  if (confirm(`Удалить доску "${board.title}"?`)) {
                    dispatch({ type: 'DELETE_BOARD', payload: { id } });
                  }
                }}
              >
                🗑️
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}