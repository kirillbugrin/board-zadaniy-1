import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div style={{ padding: 40, textAlign: 'center' }}>
      <h1>404 — Страница не найдена</h1>
      <p>Такой страницы не существует.</p>
      <Link to="/boards">← Вернуться к списку досок</Link>
    </div>
  );
}